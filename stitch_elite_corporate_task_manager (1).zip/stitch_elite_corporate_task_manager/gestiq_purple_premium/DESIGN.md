---
name: Gestiq Purple Premium
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4c4451'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#7d7483'
  outline-variant: '#cec3d3'
  surface-tint: '#7b41b3'
  primary: '#2e0052'
  on-primary: '#ffffff'
  primary-container: '#4b0082'
  on-primary-container: '#ba7ef4'
  inverse-primary: '#ddb7ff'
  secondary: '#6c49b2'
  on-secondary: '#ffffff'
  secondary-container: '#b390fe'
  on-secondary-container: '#461f8a'
  tertiary: '#26005c'
  on-tertiary: '#ffffff'
  tertiary-container: '#3f0d88'
  on-tertiary-container: '#ab84f9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f0dbff'
  primary-fixed-dim: '#ddb7ff'
  on-primary-fixed: '#2c0050'
  on-primary-fixed-variant: '#622599'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#543098'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d3bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#552c9e'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 4px
  stack-md: 12px
  stack-lg: 24px
---

## Brand & Style
The design system is engineered for high-stakes project management where clarity, authority, and premium execution are paramount. The brand personality is "Sophisticated Efficiency"—it feels like a high-end physical workspace translated into a digital interface. 

The aesthetic follows a **Corporate Modern** approach with **Minimalist** tendencies. It prioritizes information density without sacrificing whitespace, utilizing a structured hierarchy that guides the eye toward critical path actions. The emotional response should be one of calm control and professional reliability. High-contrast elements provide a sense of architectural strength, while subtle lilac tints soften the utilitarian nature of the SaaS environment.

## Colors
The palette is anchored by **Deep Purple**, used for structural weight and primary actions to establish a clear visual anchor. **Vibrant Lilac** serves as the interactive accent, providing high-visibility focus states and signaling active navigation items.

Surface colors utilize an **off-white with a lilac tint** to reduce eye strain compared to pure white, maintaining a "premium paper" feel. All status colors are calibrated for WCAG AA compliance against the background, ensuring that critical project metadata (like "Late" or "Completed") is accessible to all users. Text is kept to a **Graphite Grey** rather than pure black to maintain a sophisticated, softer contrast that remains highly legible.

## Typography
This design system utilizes **Hanken Grotesk** as the primary typeface for its sharp, contemporary geometry and exceptional readability in data-heavy SaaS environments. It strikes a balance between professional and modern.

For technical metadata and system labels, **JetBrains Mono** is introduced sparingly. This monospaced addition reinforces the "tooling" nature of the product, making IDs, timestamps, and status tags distinct from narrative content. Use tight letter spacing for large headlines to maintain a "premium" editorial feel, while keeping body text open for maximum legibility.

## Layout & Spacing
The layout follows a **12-column fluid grid** for the main content area, with a **fixed 280px sidebar** on desktop. Spacing is based on an **8px linear scale**, ensuring mathematical harmony across all components.

- **Desktop:** 32px outer margins with 24px gutters. Content is centered with a max-width of 1440px.
- **Tablet:** Sidebar collapses into a hamburger menu or icon-only rail. Margins reduce to 24px.
- **Mobile:** Single column flow. Margins reduce to 16px. Gutters are minimized to 16px to maximize screen real estate for task lists.

Vertical rhythm should be strictly maintained using the `stack` variables to separate logical sections of a page (e.g., Header to Breadcrumbs = `stack-md`, Section to Section = `stack-lg`).

## Elevation & Depth
Depth is communicated primarily through **Tonal Layers** and **Low-Contrast Outlines**. 
- **Level 0 (Background):** The lilac-tinted grey surface (#F8F7FF).
- **Level 1 (Cards/Sidebar):** Pure white surfaces with a 1px border in a very light lilac (#E5E1FF). No shadow.
- **Level 2 (Popovers/Modals):** Pure white surfaces with a soft, diffused ambient shadow (10% opacity Deep Purple tint) to indicate temporary overlay.
- **Interaction:** Active inputs and focused elements gain a 2px **Vibrant Lilac** outline, ensuring high visibility for keyboard navigation.

Avoid heavy drop shadows; the "premium" feel is achieved through crisp lines and subtle background shifts rather than artificial depth.

## Shapes
The design system uses a **Rounded (8px)** corner radius as the standard for all primary UI elements (buttons, inputs, cards). This provides a modern, approachable feel while maintaining enough structure to appear professional.

- **Standard (8px):** Buttons, Text Fields, Cards.
- **Large (16px):** Modals, Large Surface Containers.
- **Extra Large (24px):** Marketing-centric "hero" elements or large empty state illustrations.
- **Pill:** Reserved exclusively for **Status Chips** and **Avatars** to make them immediately distinguishable from actionable buttons.

## Components
- **Buttons:** Primary buttons use a **Deep Purple** background with white text. Secondary buttons use a white background with a 1px lilac border and **Vibrant Lilac** text. Tertiary buttons are text-only with a subtle lilac hover state.
- **Input Fields:** Use a 1px border (#E5E1FF) that transitions to a 2px **Vibrant Lilac** border on focus. Labels use `label-sm` in Graphite Grey.
- **Status Chips:** Use a subtle, desaturated version of the status color for the background (10% opacity) and the full-strength status color for the text and a small leading dot.
- **Cards:** White background, 8px radius, 1px light lilac border. Use `stack-md` for internal padding.
- **Progress Bars:** Track is light lilac (#E5E1FF); the indicator is **Deep Indigo**. For completed states, the indicator switches to **Dark Forest Green**.
- **Sidebar:** Uses the **Deep Purple** as a background or a very dark variant. Active links are highlighted with a **Vibrant Lilac** left-border indicator and a semi-transparent lilac background wash.