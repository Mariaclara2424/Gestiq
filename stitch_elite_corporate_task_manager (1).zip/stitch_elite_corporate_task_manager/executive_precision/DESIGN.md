---
name: Executive Precision
colors:
  surface: '#f7f9ff'
  surface-dim: '#d7dadf'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f9'
  surface-container: '#ebeef3'
  surface-container-high: '#e5e8ee'
  surface-container-highest: '#e0e3e8'
  on-surface: '#181c20'
  on-surface-variant: '#43474e'
  inverse-surface: '#2d3135'
  inverse-on-surface: '#eef1f6'
  outline: '#73777f'
  outline-variant: '#c3c6cf'
  surface-tint: '#426087'
  primary: '#002446'
  on-primary: '#ffffff'
  primary-container: '#1a3a5f'
  on-primary-container: '#87a4cf'
  inverse-primary: '#abc8f5'
  secondary: '#0055c9'
  on-secondary: '#ffffff'
  secondary-container: '#036cfb'
  on-secondary-container: '#fefcff'
  tertiary: '#351f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#523200'
  on-tertiary-container: '#c99a5f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e3ff'
  primary-fixed-dim: '#abc8f5'
  on-primary-fixed: '#001c39'
  on-primary-fixed-variant: '#2a486e'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b1c5ff'
  on-secondary-fixed: '#001946'
  on-secondary-fixed-variant: '#00419e'
  tertiary-fixed: '#ffddb7'
  tertiary-fixed-dim: '#f0bd7f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#62400c'
  background: '#f7f9ff'
  on-background: '#181c20'
  surface-variant: '#e0e3e8'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 24px
  gutter: 16px
---

## Brand & Style
The design system is engineered for high-stakes project management and corporate governance. It evokes a sense of **authority, reliability, and surgical precision**. The target audience includes project leads, executives, and high-output teams who require a tool that recedes into the background while providing clear, actionable signals.

The aesthetic follows a **Modern Corporate** movement: a synthesis of systematic functionalism and premium refinement. It prioritizes information density without sacrificing clarity, using generous whitespace to separate work streams and high-contrast accents to guide the eye toward critical path items. The emotional response is one of "command and control"—providing users with the confidence that no detail is overlooked.

## Colors
The palette is rooted in a deep **Corporate Blue (#1A3A5F)** which serves as the anchor for structural elements like navigation and primary actions. This is contrasted against an **Off-white (#F8F9FA)** canvas to reduce eye strain during long working sessions.

Status indicators are designed for immediate cognitive recognition:
- **Primary/Action:** Structural blue for the interface foundation.
- **Progressive:** Vibrant Blue for active work.
- **Review:** Defined Purple for high-level oversight.
- **Success:** Dark Green for completion, ensuring readability against light backgrounds.
- **Alert:** Deep Red for late tasks or blockers, maintaining a professional rather than alarming tone.

All text-to-background combinations must maintain a minimum 4.5:1 contrast ratio to ensure WCAG AA compliance.

## Typography
The typographic system uses a dual-font approach to balance character with utility. **Hanken Grotesk** is used for headlines and display elements, providing a modern, sharp edge that feels contemporary and "startup-nimble." 

**Inter** is utilized for all body copy, data tables, and input fields. Its neutral, systematic nature excels in high-density environments where legibility is paramount. Large display titles use a slight negative letter-spacing for a more compact, "editorial" feel, while labels and metadata use increased tracking and uppercase styling to differentiate them from actionable text.

## Layout & Spacing
The layout follows a **Fixed-Fluid hybrid grid**. The primary sidebar is fixed at 280px to maintain a constant anchor, while the main content area utilizes a 12-column fluid grid. 

A strict **8px linear scale** governs all spatial relationships. 
- **Margins:** 24px for standard page containers.
- **Gutters:** 16px between grid columns to maximize data density while maintaining separation.
- **Mobile:** On screens below 768px, the 12-column grid collapses into a single-column stack, and page margins reduce to 16px.

Alignment is strictly left-heavy to support fast scanning patterns common in project management.

## Elevation & Depth
This design system utilizes **Tonal Layers** supplemented by **Low-contrast Outlines** rather than heavy shadows. Depth is communicated through surface color shifts (e.g., a slightly darker grey for the sidebar or header) to keep the UI feeling flat and fast.

- **Level 0 (Floor):** The #F8F9FA background.
- **Level 1 (Card/Surface):** Pure white (#FFFFFF) with a 1px border in #DEE2E6. No shadow.
- **Level 2 (Dropdowns/Modals):** Pure white (#FFFFFF) with a 1px border and a subtle "Ambient Shadow" (0px 4px 12px rgba(0, 0, 0, 0.08)) to indicate temporary overlay.

Focus states use a high-visibility, 2px solid stroke of the Secondary Blue (#0D6EFD) with a 2px offset to ensure keyboard navigation is unmistakable.

## Shapes
The shape language is **Soft (0.25rem / 4px)**. This subtle rounding removes the harshness of 90-degree corners—suggesting a modern interface—while maintaining a sense of professional structure. 

- **Buttons & Inputs:** 4px radius.
- **Large Cards/Modals:** 8px (rounded-lg) for a more contained, premium feel.
- **Avatars:** Circular (Pill) to provide a soft counterpoint to the otherwise rectangular grid.

## Components
- **Buttons:** Primary buttons use the Corporate Blue background with white text. Secondary buttons use a 1px border in #DEE2E6 with Corporate Blue text. Use "Large" (48px height) for main CTAs and "Small" (32px) for table actions.
- **Chips/Badges:** Use high-contrast backgrounds corresponding to the status colors. Text should be white or high-contrast dark depending on the status color luminance.
- **Input Fields:** Use white backgrounds with 1px #DEE2E6 borders. On focus, the border transitions to #1A3A5F. Labels are always positioned above the field for clarity.
- **Cards:** White containers with 4px radius and 1px light-grey borders. No shadows for standard task cards; reserved for hovered states or active selection.
- **Lists:** High-density rows (48px height) with subtle bottom borders. Every third row may use a "Zebra" stripe of #F1F3F5 to aid horizontal scanning.
- **Progress Bars:** Use a thick 8px track in #E9ECEF with a high-contrast #0D6EFD fill for "In Progress" tasks.